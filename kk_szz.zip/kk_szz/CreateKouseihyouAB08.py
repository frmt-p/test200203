from tkinter import *
from tkinter import ttk
import numpy as np
import sys
import io
import os

import ezdxf
import datetime


def MojibakeTaisaku():
    # 出力の文字化け対策
    sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8')
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

def defLayers(doc,LyName,LyColor):
    #画層の定義
    doc.layers.new(name=LyName, dxfattribs={'linetype': 'DASHED', 'color': LyColor})
    # doc.layers.new(name="MyLine2", dxfattribs={'linetype': 'CONTINUOUS', 'color': 1})
    # doc.layers.new(name="MyLine3", dxfattribs={'linetype': 'CENTER', 'color': 2})

def Add_Rectangle(msp,LyName, x,y,w,h):
    msp.add_line([x, y], [x+w, y])
    msp.add_line([x+w, y], [x+w, y-h])
    msp.add_line([x+w, y-h], [x, y-h])
    msp.add_line([x, y-h], [x, y])


def Add_Text(msp,LyName, x,y,txt,alignType,LineLR,kigunaiTF):
    # テキスト挿入
    # https://www.javaer101.com/ja/article/3512194.html
    mtext = msp.add_text(txt).set_pos((x,y),align=alignType)
    # mtext = msp.add_text(txt).set_pos((x,y),align=alignType, dxfattribs={'layer': LyName})
    mtext.scale(0.55,1,0)                    # 横幅を縮める
    mtext.set_pos((x,y),align=alignType)    # pos再配置

    w = 3  # 線の幅
    dx = 2
    if not txt=='':
        if LineLR == 'L':
            msp.add_line([x-dx, y], [x-dx-w, y])                                                    # 実線を入れる
            if kigunaiTF == TRUE:
                msp.add_line([x-dx-w, y], [x-dx-2*w, y], dxfattribs={'layer': 'Tensen'})            # 点線を入れる
        if LineLR == 'R':
            msp.add_line([x+dx, y], [x+dx+w, y])                                                    # 実線を入れる
            if kigunaiTF == TRUE:
                msp.add_line([x+dx+w, y], [x+dx+2*w, y], dxfattribs={'layer': 'Tensen'})            # 点線を入れる
            # msp.add_polyline2d([x+dx+w, y], [x+dx+2*w, y],close=False)  # 点線を入れる

class dxf_Area:
    def __init__(self,Top,Left,h,w):
        self.Top=Top
        self.Left=Left
        self.h=h
        self.w=w

def open_dxf(dxfName):
    os.chdir(os.path.dirname(os.path.abspath(__file__)))    # pyファイルのあるフォルダに移動する
    doc = ezdxf.readfile("kkBASE.dxf")  # 既存のdxfテンプレを開く
    return doc

def create_dxf(n,posH, doc, LinName, CableType, TypeAB):        
    msp = doc.modelspace() #add new entities to the modelspace
    defLayers(doc, 'ezdxf'+str(posH+1), 7)
    LyName = 'ezdxf'+str(posH+1)
    print(posH,LyName)

    kigusu = len(CableType)#-1
    print('kigusu',kigusu)
    ct1=CableType[0]
    print('ct1',ct1)
    for i in range(1,kigusu):
        ct=CableType[i]
        da=dxf_Area(110, -175, 300, 270)
        # da=dxf_Area(110, -175, 265, 240)

        # 矩形生成
        x_init = -50 -da.w/(m)*((m-1)/2)
        dHpos = (5+6)*(n)
        y_init = da.Top - dHpos*(posH)
        dx_Rectangle = da.w/(m)
        y_Rectangle = 0
        x_Rec,y_Rec,w,h = (i-1)*dx_Rectangle+x_init ,y_Rectangle+y_init , 15, 5*(n+1)
        Add_Rectangle(msp,LyName,x_Rec,y_Rec,w,h)

        # テキスト生成
        dy_Text = h/(n+2)
        x_TextL = -5
        x_TextM = w/2
        x_TextR = w - x_TextL

        for j in range(0,len(ct)-1):
            y_txt = y_Rec - dy_Text*(j+2)
            #  線名
            x_txtC  = x_Rec + x_TextM
            txt=LinName[j]
            Add_Text(msp,LyName,x_txtC,y_txt,txt,'MIDDLE_CENTER','',True)

            if TypeAB == 'A':
                # 左側:1次側
                x_txtL  = x_Rec + x_TextL
                Add_Text(msp,LyName,x_txtL,y_txt,ct1[j],'MIDDLE_RIGHT','R',True)
                # 右側:2次側
                x_txtR  = x_Rec + x_TextR
                Add_Text(msp,LyName,x_txtR,y_txt,ct[j],'MIDDLE_LEFT','L',True)

            elif TypeAB == 'B':
                # 右側:1次側
                x_txtR  = x_Rec + x_TextR
                Add_Text(msp,LyName,x_txtR,y_txt,ct1[j],'MIDDLE_LEFT','L',True)
                # 左側:2次側
                x_txtL  = x_Rec + x_TextL
                Add_Text(msp,LyName,x_txtL,y_txt,ct[kigusu-1-j],'MIDDLE_RIGHT','R',True)

        # アース線生成
        dy=3
        if TypeAB == 'A':
            Add_Text(msp,LyName,x_txtL, y_init-dy_Text,'IV5.5sq','MIDDLE_RIGHT','R',False)
        elif  TypeAB == 'B':
            Add_Text(msp,LyName, x_txtR, y_init-dy_Text,'IV5.5sq','MIDDLE_LEFT','L',False)

        # 器具名枠生成
        Add_Text(msp,LyName, x_txtC,y_init+dy*1,'<器具名>','MIDDLE_CENTER','',False)
        # 上下線枠生成
        Add_Text(msp,LyName, x_txtC,y_init+dy*2,'上下り線用','MIDDLE_CENTER','',False)
        # Type名生成
        Add_Text(msp,LyName, x_txtC,y_init-h-dy*1,'Type'+TypeAB,'MIDDLE_CENTER','',False)
        # 図番枠生成
        Add_Text(msp,LyName, x_txtC,y_init-h-dy*2,'T3CL*****K*','MIDDLE_CENTER','',False)

    # DXFファイル出力
    doc.saveas(dxfName + '.dxf')


#入力用のGUI
def GUI_Input(n, m, posH, doc,TypeAB):
    root = Tk()
    root.title('【区分開閉器 構成表入力フォーム】（' + str(posH+1)+'段目:' + 'Type'+TypeAB + '）')

    #入力用フレーム
    frame = ttk.Frame(root)
    frame.grid(row=0, column=0)

    listObj = [0]*(2*n + 3*n*(m+1))

    cTypelist = ['VVR','VF']
    cMSlist = ['(幹)','(枝)']
    cDimlist = [3.5,5.5,8,14,22,38,60]
    cclist = [3,4,5]

    k=p=0

    if TypeAB == 'A':
        Arrow = ' -> '
    elif  TypeAB == 'B':
        Arrow = ' <- '

    for i in range(0, n):   #　要素数：2*n
        # 1次側 -------------------------------------------
        lbl = ttk.Label(text='線名：' + str(i+1))
        lbl.grid(row=i+1, column=0)

        listObj[k] = ttk.Entry(width=10)
        listObj[k].grid(row=i+1, column=1)
        k+=1

        listObj[k] = ttk.Combobox(values=cMSlist,width = 4)
        # デフォルトの値を設定
        listObj[k].current((i+1)%2)
        listObj[k].grid(row=i+1, column=2)
        k+=1

        # 区切り線
        lbl = ttk.Label(text=' ： ')
        lbl.grid(row=i+1, column=3)


    for j in range(0,m+1):    # 器具数：m
        # 2次側 -------------------------------------------
        col=j*8
        for i in range(0, n):   # 要素数：3*n
            lbl = ttk.Label(text=Arrow)
            lbl.grid(row=i+1, column=col+4)

            listObj[k] = ttk.Combobox(values=cTypelist,width = 4)
            listObj[k].grid(row=i+1, column=col+5)
            k+=1

            listObj[k] = ttk.Combobox(values=cDimlist,width = 3)
            listObj[k].grid(row=i+1, column=col+6)
            k+=1

            lbl = ttk.Label(text='sq')
            lbl.grid(row=i+1, column=col+7)

            listObj[k] = ttk.Combobox(values=cclist,width = 3)
            listObj[k].grid(row=i+1, column=col+8)
            k+=1

            lbl = ttk.Label(text='c')
            lbl.grid(row=i+1, column=col+9)

    # タイトル行 -------------------------------------------
    lbl1 = ttk.Label(text='<- 1次側')
    lbl1.grid(row=0, column=0+8)
    lbl2 = ttk.Label(text='2次側 ->')
    lbl2.grid(row=0, column=5+8)
    
    #コンボボックスからデータを取得し２次元配列としてpritnt出力
    def ButtonClicked_Run():
        ub = len(listObj)
        ls=[0]*(ub)
        LinName=[0]*(n)
        CableType=[0]*((m+1)*n)

        # 全部を１次元に
        for i in range(ub):
            ls[i]=listObj[i].get()

        # 線名と線種を１次元でそれぞれ分ける
        for i in range(0,n):
            LinName[i] = ls[2*i] + ls[2*i+1]

        kugiri = 2*n
        print(LinName)

        for i in range((m+1)*n):
            if not ls[3*i+kugiri] == '':
                CableType[i] = ls[3*i+kugiri]+' ' + ls[3*i+kugiri+1]+'sq-' +  ls[3*i+kugiri+2]+'c'
            else:
                CableType[i] = ''

        # ２次元化する
        CableType=np.reshape(CableType,((m+1),n))
        print(CableType)
        # dxfに書き込む
        create_dxf(n, posH, doc, LinName, CableType, TypeAB)

        # GUIを閉じる
        root.destroy()

    #実行ボタンの設置
    j=1
    button_Run = ttk.Button(root,
                            text='実行',
                            padding=5,
                            command=ButtonClicked_Run)
    button_Run.grid(row=99, column=99)

    root.mainloop()

    # 続けるか問う
    NextYN = input('次の段を入力しますか？(Y/N) >>> ')
    print(NextYN)
    return NextYN

if __name__ == '__main__':
    #n、mの数を変えて、行列のサイズを指定
    n,m = 3,0
    now = datetime.datetime.now()
    t = now.strftime("%y%m%d_%H%M%S")
    dxfName='kk'+t
    doc = open_dxf(dxfName)
    defLayers(doc,'Tensen',7)   # 点線用

    MojibakeTaisaku()

    while m > 5 or m<1:
        m = int(input('1段に描画する器具数を入力してください。 最大5 >>> '))

    # ループ変数初期化
    posH=0
    NextYN='Y'
    TypeAB=''
    while NextYN.upper()=='Y':
        while not TypeAB.upper() == 'A' and not TypeAB.upper() == 'B':
            TypeAB = input('Typeを選択してください。A or B >>> ')
            NextYN = GUI_Input(n*2,m, posH, doc,TypeAB.upper())
            posH+=1
        TypeAB=''

    os._exit( )


